-- AlterTable
ALTER TABLE "spk_item" ADD COLUMN     "overproductionChoice" TEXT;
