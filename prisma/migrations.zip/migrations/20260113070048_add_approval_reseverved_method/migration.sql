-- AlterTable
ALTER TABLE "spk_item" ALTER COLUMN "updatedAt" DROP DEFAULT;
