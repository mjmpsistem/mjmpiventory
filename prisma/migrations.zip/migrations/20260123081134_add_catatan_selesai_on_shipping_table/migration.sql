-- AlterTable
ALTER TABLE "shipping" ADD COLUMN     "catatanSelesai" TEXT;
