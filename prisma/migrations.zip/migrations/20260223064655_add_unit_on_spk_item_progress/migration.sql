-- AlterTable
ALTER TABLE "spk_item_progress" ADD COLUMN     "unit" TEXT,
ADD COLUMN     "wasteUnit" TEXT;
