-- AlterTable
ALTER TABLE "spk" ADD COLUMN     "signedUrl" TEXT;
