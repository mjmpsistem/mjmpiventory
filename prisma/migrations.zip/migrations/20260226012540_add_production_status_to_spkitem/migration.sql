-- AlterTable
ALTER TABLE "spk_item" ADD COLUMN     "productionStatus" TEXT;
