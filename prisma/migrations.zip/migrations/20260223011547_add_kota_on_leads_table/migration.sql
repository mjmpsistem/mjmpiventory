-- AlterTable
ALTER TABLE "leads" ADD COLUMN     "kota" TEXT;
