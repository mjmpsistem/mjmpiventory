-- AlterTable
ALTER TABLE "return_item" ADD COLUMN     "isHandled" BOOLEAN NOT NULL DEFAULT false;
