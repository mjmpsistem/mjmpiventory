-- AlterTable
ALTER TABLE "invoice" ADD COLUMN     "isPartial" BOOLEAN NOT NULL DEFAULT false;
